Unit 18 Nosql Homework: Workout Tracker
I have created a workout tracker. With the already provided front end code in the Develop folder I  created a Mongo database with a Mongoose schema to handle routes with Express.


You are able to view, create and track daily workouts. You are able to log multiple exercises in a workout on a given day. You are also be able to track the name, type, weight, sets, reps, and duration of each exercise. If the exercise is a cardio exercise, you will be able to track the distance traveled.


With this app, you will better be able to reach your fitness goals. These goals will be reached quicker when you track your workout progress.





Submission on BCS
You are required to submit the following:

The URL to the deployed application

The URL to the GitHub repository