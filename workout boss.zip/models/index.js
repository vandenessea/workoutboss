module.exports = {
    Workout: require('./Workout')
}